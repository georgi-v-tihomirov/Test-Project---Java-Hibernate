import dao.CompanyDAO;
import dao.DetailDAO;
import dao.EmployeeDAO;
import entity.*;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import java.util.Set;

public class Main {
    public static void main(String[] args) {
        //Creating company
        Company company = new Company("SAP", BigDecimal.valueOf(5_000), LocalDate.of(2015, 4, 10));
        CompanyDAO.saveCompany(company);
        Company t = CompanyDAO.getCompany(1);
        System.out.println(t);

        //Add employees
        Employee emp1 = new Employee("Regina Queen", EmployeeType.EXPERIENCED, LocalDate.of(1987, 2, 22));
        emp1.setWorkingInCompany(t);
        EmployeeDAO.saveEmployee(emp1);
        Employee emp2 = new Employee("Daenerys", EmployeeType.INEXPERIENCED, LocalDate.of(1957, 7, 4));
        emp2.setWorkingInCompany(t);
        EmployeeDAO.saveEmployee(emp2);

        //5
        System.out.println("Company employees: 5 task -------------------------");
        Set<Employee> setEMP = CompanyDAO.employeesInCompany(t);
        for(Employee e : setEMP){
            System.out.println(e.getEmployeeName());
        }

        //Add details
        Detail d = new Detail("FIRST class el 1", DetailDesignedFor.WHEEL, 3, DetailMaterial.METAL, 32.00);
        Detail d1 = new Detail("FIRST class el 2", DetailDesignedFor.DOOR, 15, DetailMaterial.PLASTIC, 15.00);
        Employee e = EmployeeDAO.getEmployee(2);
        //d.setDetailCreatedByEmployee(e);
        //d1.setDetailCreatedByEmployee(e);
        e.createDetail(d);
        e.createDetail(d1);
        DetailDAO.saveDetail(d);
        DetailDAO.saveDetail(d1);

        //6
        //Employee e = EmployeeDAO.getEmployee(1);
        //Set<Employee> setEMP = CompanyDAO.employeesInCompany(t);
        System.out.println("Employees and details: 6 task -------------------------");
        for(Employee emp : setEMP) {
            Set<Detail> s = DetailDAO.getAllDetailsCreatedFromEmployee(emp);
            System.out.println(emp.getEmployeeName() + "has created: " + (s.size()!=0 ? s.size() : "none" ) + " details.");
            for (Detail det : s) {
                System.out.println(det.getDetailName() + ", quantity: " + det.getDetailQuantity());
            }
        }

        //Company t = CompanyDAO.getCompany(1);
        System.out.println("Income: " + CompanyDAO.getCompanyIncome(t));//1
        System.out.println("Profit: " + CompanyDAO.getCompanyProfit(t));//3
        System.out.println("Profit after tax: " + CompanyDAO.getCompanyProfitAfterTax(t, 20));//4
        System.out.println("Company monthly expenses: " + CompanyDAO.getCompanyExpenses(t, 20));//2

        //7

        List<Detail> det = DetailDAO.getAllDetailsCreatedFromCompany(t);
        System.out.println("Details by company: 7 task -------------------------");
        for(Detail de : det){
            System.out.println(de.getDetailName() + ", quantity: " + de.getDetailQuantity());
        }

        /*
        Detail d = new Detail("kapak", DetailDesignedFor.WHEEL, DetailMaterial.METAL);
        Detail d1 = new Detail("guma", DetailDesignedFor.DOOR, DetailMaterial.PLASTIC);
        Employee e = EmployeeDAO.getEmployee(2);
        d.setDetailCreatedByEmployee(e);
        d1.setDetailCreatedByEmployee(e);
        DetailDAO.saveDetail(d);
        DetailDAO.saveDetail(d1);*/

        /*
        Company t = CompanyDAO.getCompany(2);
        List<Detail> s = DetailDAO.allDetailsCreatedFromCompany(t);
        for(Detail d : s){
            System.out.println(d.getDetailName() + " " + d.getDetailQuantity());
        }

        //works
        /*
        Detail d = new Detail("SECOND class el 1", DetailDesignedFor.WHEEL, 3, DetailMaterial.METAL);
        Detail d1 = new Detail("SECOND class el 2", DetailDesignedFor.DOOR, 15, DetailMaterial.PLASTIC);
        Employee e = EmployeeDAO.getEmployee(3);
        d.setDetailCreatedByEmployee(e);
        d1.setDetailCreatedByEmployee(e);
        DetailDAO.saveDetail(d);
        DetailDAO.saveDetail(d1);


        //works
        /*
        Employee e = EmployeeDAO.getEmployee(1);
        Set<Detail> s = DetailDAO.allDetailsCreatedFromEmployee(e);
        for(Detail d : s){
            System.out.println(d.getDetailName() + " " + d.getDetailQuantity());
        }




        //works

        //Company t = CompanyDAO.getCompany(1);
        /*

        Set<Employee> s = EmployeeDAO.employeesInCompany(t);
        for(Employee e : s){
            System.out.println(e.getEmployeeName());
        }
        */


        //Employee emp1 = new Employee("Regina Queen", EmployeeType.EXPERIENCED, LocalDate.of(1987, 2, 22));
        //emp1.setWorkingInCompany(t);
        //EmployeeDAO.saveEmployee(emp1);
        //Employee emp2 = new Employee("Daenerys", EmployeeType.INEXPERIENCED, LocalDate.of(1957, 7, 4));
        //emp2.setWorkingInCompany(t);
        //EmployeeDAO.saveEmployee(emp2);

        //works
        //List<Detail> d = DetailDAO.getDetails();
        //for(Detail de : d){
        //    System.out.println(de.toString());
        //}

        //works
        //Employee e = EmployeeDAO.getEmployee(1);
        //Detail d = DetailDAO.getDetail(2);
        //System.out.println(d);
        //d.setDetailDesignedFor(DetailDesignedFor.seat);
        //DetailDAO.saveOrUpdateDetail(d);
        //d1.setDetailCreatedByEmployee(e);
        //DetailDAO.saveDetail(d1);

        //Company t = CompanyDAO.getCompany(2);
        //Employee emp2 = new Employee("SECONDcompanyEMP", EmployeeType.INEXPERIENCED, LocalDate.of(1957, 7, 4));
        //emp2.setWorkingInCompany(t);
        //EmployeeDAO.saveEmployee(emp2);
        //System.out.println(t);

        //works BUT with commented lines
        //Employee e = EmployeeDAO.getEmployee(1);
        //e.setEmployeeType(EmployeeType.experienced);
        //EmployeeDAO.saveOrUpdateEmployee(e);

        //NEEDS EAGER???????????????????????????? but works
        //Employee emp1 = new Employee("Willemina Slayyyter",  LocalDate.of(1997, 3, 20));
        //emp1.setWorkingInCompany(t);
        //EmployeeDAO.saveEmployee(emp1);

        //works
        //Company company = new Company("SAP", BigDecimal.valueOf(5_000), LocalDate.of(2015, 4, 10));
        //Company company1 = new Company("SAPp", BigDecimal.valueOf(5_000), LocalDate.of(2015, 4, 10));
        //CompanyDAO.saveCompany(company);
        //CompanyDAO.saveCompany(company1);

        //works
        //Company c1 = CompanyDAO.getCompany(3);
        //System.out.println(c1);

        //not working - not doing anything
        //CompanyDAO.deleteCompany(company);

        //not working - not adding - idk
        /*
        List companyList = new List();
        Company company2 = new Company("Test1", BigDecimal.valueOf(15_000), LocalDate.of(2010, 3, 20));
        Company company3 = new Company("Test2", BigDecimal.valueOf(5_000), LocalDate.of(2015, 4, 10));
        companyList.add(company2);
         */

        //fill database

        /*
        Company company = new Company("SAP", BigDecimal.valueOf(5_000), LocalDate.of(2015, 4, 10));
        Company company1 = new Company("SAPp", BigDecimal.valueOf(5_000), LocalDate.of(2015, 4, 10));
        CompanyDAO.saveCompany(company);
        CompanyDAO.saveCompany(company1);

        Company t = CompanyDAO.getCompany(1);

        Employee emp1 = new Employee("Regina Queen", EmployeeType.EXPERIENCED, LocalDate.of(1987, 2, 22));
        emp1.setWorkingInCompany(t);
        EmployeeDAO.saveEmployee(emp1);
        Employee emp2 = new Employee("Daenerys", EmployeeType.INEXPERIENCED, LocalDate.of(1957, 7, 4));
        emp2.setWorkingInCompany(t);
        EmployeeDAO.saveEmployee(emp2);

        Detail d = new Detail("FIRST class el 1", DetailDesignedFor.WHEEL, 3, DetailMaterial.METAL, 32.00);
        Detail d1 = new Detail("FIRST class el 2", DetailDesignedFor.DOOR, 15, DetailMaterial.PLASTIC, 15.00);
        Employee e = EmployeeDAO.getEmployee(2);
        d.setDetailCreatedByEmployee(e);
        d1.setDetailCreatedByEmployee(e);
        DetailDAO.saveDetail(d);
        DetailDAO.saveDetail(d1);


        //works
        //Company t = CompanyDAO.getCompany(1);
        //System.out.println(CompanyDAO.getCompanyIncome(t));
        //System.out.println(CompanyDAO.getCompanyProfit(t));
        //System.out.println(CompanyDAO.getCompanyProfitAfterTax(t, 20));


        ///////////////////////////////////////////////////////////////////////////////Create detail in employee function
        /////////////////////////////Calculate adequate detail retail price


        // doesnt workkkkkkkkkk
        Company temp = CompanyDAO.getCompany(1);
        System.out.println(temp.getName());
        //System.out.println(CompanyDAO.getCompanyProfit(temp));
        System.out.println(CompanyDAO.getAllCreatedDetails(temp));
        /*Set<Detail> det = CompanyDAO.getAllCreatedDetails(temp);
        for(Detail de : det){
            System.out.println(de.getDetailName());
        }*/

    }
}
