package dao;

import configuration.SessionFactoryUtil;
import entity.Company;
import entity.Detail;
import entity.Employee;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

public class DetailDAO {

    public static void saveDetail(Detail detail) {
        try (Session session = SessionFactoryUtil.getSessionFactory().openSession()) {
            Transaction transaction = session.beginTransaction();
            //detail.getWorkingInCompany().addEmployee(detail);
            detail.getDetailCreatedByEmployee().addToCreatedDetails(detail);
            session.save(detail);
            transaction.commit();
        }
    }

    public static void saveOrUpdateDetail(Detail detail) {
        try (Session session = SessionFactoryUtil.getSessionFactory().openSession()) {
            Transaction transaction = session.beginTransaction();
            //throws non unique object???
            //Company company1 = session.find(Company.class, employee.getWorkingInCompany().getId());
            //Hibernate.initialize(company1);
            //company1.addEmployee(employee);
            session.saveOrUpdate(detail);
            transaction.commit();
        }
    }

    public static Detail getDetail(long id) {
        Transaction transaction = null;
        Detail detail;
        try (Session session = SessionFactoryUtil.getSessionFactory().openSession()) {
            transaction = session.beginTransaction();
            // get entity.entity.Employee entity using get() method
            detail = session.get(Detail.class, id);
            transaction.commit();
        }
        return detail;
    }

    public static List<Detail> getDetails() {
        try (Session session = SessionFactoryUtil.getSessionFactory().openSession()) {
            return session.createQuery("FROM entity.Detail", Detail.class).list();
        }
    }

    //6
    public static Set<Detail> getAllDetailsCreatedFromEmployee(Employee employee) {
        List<Detail> details;
        try (Session session = SessionFactoryUtil.getSessionFactory().openSession()) {
            details = session.createQuery("FROM Detail WHERE created_by_employee_id = "
                    + employee.getEmployeeId()).getResultList();
        }
        return details.stream().collect(Collectors.toSet());
    }

    //7
    public static List<Detail> getAllDetailsCreatedFromCompany(Company company) {
        try (Session session = SessionFactoryUtil.getSessionFactory().openSession()) {
            Query query = session
                    .createNativeQuery("SELECT * FROM detail JOIN employee " +
                            "ON employee.employee_id = detail.created_by_employee_id AND employee.employee_company_id = :company_id", Detail.class);
            query.setParameter("company_id", company.getId());
            return query.getResultList();
        }
    }
}
