package dao;

import configuration.SessionFactoryUtil;
import entity.Employee;
import org.hibernate.Session;
import org.hibernate.Transaction;

import java.util.List;

public class EmployeeDAO {
    public static void saveEmployee(Employee employee) {
        try (Session session = SessionFactoryUtil.getSessionFactory().openSession()) {
            Transaction transaction = session.beginTransaction();
            employee.getWorkingInCompany().addEmployee(employee);
            session.save(employee);
            transaction.commit();
        }
    }

    public static void saveOrUpdateEmployee(Employee employee) {
        try (Session session = SessionFactoryUtil.getSessionFactory().openSession()) {
            Transaction transaction = session.beginTransaction();
            //throws non unique object???
            //Company company1 = session.find(Company.class, employee.getWorkingInCompany().getId());
            //Hibernate.initialize(company1);
            //company1.addEmployee(employee);
            session.saveOrUpdate(employee);
            transaction.commit();
        }
    }

    /*
    public static List<Employee> getEmployees() {
        try (Session session = SessionFactoryUtil.getSessionFactory().openSession()) {
            return session.createQuery("FROM entity.Employee", Employee.class).list();
        }
    }
*/
    public static Employee getEmployee(long id) {
        Transaction transaction = null;
        Employee employee;
        try (Session session = SessionFactoryUtil.getSessionFactory().openSession()) {
            transaction = session.beginTransaction();
            // get entity.entity.Employee entity using get() method
            employee = session.get(Employee.class, id);
            transaction.commit();
        }
        return employee;
    }

    public static List<Employee> getEmployees() {
        try (Session session = SessionFactoryUtil.getSessionFactory().openSession()) {
            return session.createQuery("FROM entity.Employee", Employee.class).list();
        }
    }

}
