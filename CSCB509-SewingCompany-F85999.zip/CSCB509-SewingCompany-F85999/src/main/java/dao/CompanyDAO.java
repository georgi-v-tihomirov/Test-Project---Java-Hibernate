package dao;

import configuration.SessionFactoryUtil;
import entity.Company;
import entity.Employee;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

public class CompanyDAO {
    public static void saveCompany(Company company) {
        try (Session session = SessionFactoryUtil.getSessionFactory().openSession()) {
            Transaction transaction = session.beginTransaction();
            session.save(company);
            transaction.commit();
        }
    }

    public static void saveOrUpdateCompany(Company company) {
        try (Session session = SessionFactoryUtil.getSessionFactory().openSession()) {
            Transaction transaction = session.beginTransaction();
            session.saveOrUpdate(company);
            transaction.commit();
        }
    }

    /*
    public static void saveCompanies(List<Company> companyList) {
        try (Session session = SessionFactoryUtil.getSessionFactory().openSession()) {
            Transaction transaction = session.beginTransaction();
            companyList.stream().forEach((com) -> session.save(com));
            transaction.commit();
        }
    }
     */

    public static Company getCompany(long id) {
        Transaction transaction = null;
        Company company;
        try (Session session = SessionFactoryUtil.getSessionFactory().openSession()) {
            transaction = session.beginTransaction();
            // get entity.entity.Company entity using get() method
            company = session.get(Company.class, id);
            transaction.commit();
        }
        return company;
    }

    public static List<Company> getCompanies() {
        try (Session session = SessionFactoryUtil.getSessionFactory().openSession()) {
            return session.createQuery("FROM entity.Company", Company.class).list();
        }
    }

    //3 - Get profit from retail price minus detail price
    public static double getCompanyProfit(Company company) {
        try (Session session = SessionFactoryUtil.getSessionFactory().openSession()) {
            Query query = session
                    .createNativeQuery("SELECT SUM(detail_retail_price) - SUM(detail_price) FROM detail JOIN employee " +
                            "ON detail.created_by_employee_id = employee.employee_id WHERE employee.employee_company_id = :company_id");
            query.setParameter("company_id", company.getId());
            double queryResultSum = (double)query.getSingleResult();
            return Math.round(queryResultSum * 100.0) / 100.0;
        }
    }

    //5 - Employee list
    public static Set<Employee> employeesInCompany(Company company) {
        List<Employee> employees;
        try (Session session = SessionFactoryUtil.getSessionFactory().openSession()) {
            employees = session.createQuery("FROM Employee WHERE employee_company_id = "
                    + company.getId()).getResultList();
        }
        return employees.stream().collect(Collectors.toSet());
    }

    //1 - Get income from detail retail price
    public static double getCompanyIncome(Company company) {
        try (Session session = SessionFactoryUtil.getSessionFactory().openSession()) {
            Query query = session
                    .createNativeQuery("SELECT SUM(detail_retail_price) FROM detail JOIN employee " +
                            "ON detail.created_by_employee_id = employee.employee_id WHERE employee.employee_company_id = :company_id");
            query.setParameter("company_id", company.getId());
            return (double)query.getSingleResult();
        }
    }

    //2 - Get company expenses
    public static double getCompanyExpenses(Company company, int workingDaysInMonth) {
        try (Session session = SessionFactoryUtil.getSessionFactory().openSession()) {
            Query query = session
                    .createNativeQuery("SELECT SUM(detail.detail_price) + SUM(employee.wage_per_hour * employee.working_hours_day) * :workingDaysInMonth FROM detail JOIN employee " +
                            "ON detail.created_by_employee_id = employee.employee_id WHERE employee.employee_company_id = :company_id");
            query.setParameter("company_id", company.getId());
            query.setParameter("workingDaysInMonth", workingDaysInMonth);
            double queryResultSum = (double)query.getSingleResult();
            return Math.round(queryResultSum * 100.0) / 100.0;
        }
    }

    //4 - Get profit after tax
    public static double getCompanyProfitAfterTax(Company company, double taxPercent) {
        try (Session session = SessionFactoryUtil.getSessionFactory().openSession()) {
            Query query = session
                    .createNativeQuery("SELECT SUM(detail_retail_price) - SUM(detail_price) FROM detail JOIN employee " +
                            "ON detail.created_by_employee_id = employee.employee_id WHERE employee.employee_company_id = :company_id");
            query.setParameter("company_id", company.getId());
            double queryResultSum = (double)query.getSingleResult();
            //Calculate the tax percentage - queryResultSum - taxPercent/100 * queryResultSum and round the number
            //to two decimal places Math.round(sum * 100.0) / 100.0
            return Math.round((queryResultSum - taxPercent/100 * queryResultSum) * 100.0) / 100.0;
        }
    }

    /*
    public static void deleteCompany(Company company) {
        try (Session session = SessionFactoryUtil.getSessionFactory().openSession()) {
            Transaction transaction = session.beginTransaction();
            session.delete(company);
            transaction.commit();
        }
    }*/
}
