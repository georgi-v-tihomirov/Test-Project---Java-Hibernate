package entity;

import javax.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.HashSet;
import java.util.Set;

@Entity
@Table(name = "company")
public class Company {

    @Id
    @Column(name = "company_id", updatable = false, nullable = false)
    @GeneratedValue(strategy = GenerationType.AUTO)
    private long id;

    @Column(name = "company_name", nullable = false)
    private String name;

    @Column(name = "initial_capital", nullable = false)
    private BigDecimal initialCapital;

    @Column(name = "foundation_date")
    private LocalDate foundationDate;

    @OneToMany(mappedBy = "workingInCompany", fetch = FetchType.EAGER,
            cascade = CascadeType.ALL, orphanRemoval = false)
    private Set<Employee> employeeList;

    public Company() {
        employeeList = new HashSet();
    }

    public Company(String name) {
        setName(name);
        employeeList = new HashSet();
    }

    public Company(String name, BigDecimal initialCapital, LocalDate foundationDate) {
        setName(name);
        setInitialCapital(initialCapital);
        setFoundationDate(foundationDate);
        employeeList = new HashSet();
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public BigDecimal getInitialCapital() {
        return initialCapital;
    }

    public void setInitialCapital(BigDecimal initialCapital) {
        this.initialCapital = initialCapital;
    }

    public LocalDate getFoundationDate() {
        return foundationDate;
    }

    public void setFoundationDate(LocalDate foundationDate) {
        this.foundationDate = foundationDate;
    }

    public Set<Employee> getEmployeeList() {
        return employeeList;
    }

    public void setEmployeeList(Set<Employee> employeeList) {
        this.employeeList = employeeList;
    }

    //Hire employee
    public void addEmployee(Employee employee) {
        this.employeeList.add(employee);
        employee.setWorkingInCompany(this);
    }

    //Fire employee
    public void removeEmployee(Employee employee) {
        this.employeeList.remove(employee);
    }

    @Override
    public String toString() {
        return "entity.Company{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", initialCapital=" + initialCapital +
                ", foundationDate=" + foundationDate +
                '}';
    }
}
