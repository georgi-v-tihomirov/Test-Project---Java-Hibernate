package entity;

public enum DetailDesignedFor {
    DOOR(1.30), WHEEL(0.30), SEAT(2.00);

    private double timeForMaking;

    DetailDesignedFor(double time) { this.timeForMaking = time; }

    public double getTimeForMaking() { return timeForMaking; }

}
