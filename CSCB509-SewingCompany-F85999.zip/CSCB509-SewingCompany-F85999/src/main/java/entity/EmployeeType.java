package entity;

public enum EmployeeType {
    EXPERIENCED(35.00, 8, 5), INEXPERIENCED(20.00, 4, 2);

    private double wage;
    private int workingHours;
    private int maxDetailsProducedPerHour;///How to track time?

    EmployeeType(double wage, int hours, int details) {
        this.wage = wage;
        this.workingHours = hours;
        this.maxDetailsProducedPerHour = details;
    }

    public double getWage() {
        return wage;
    }

    public int getWorkingHours() {
        return workingHours;
    }

    public int getMaxDetailsProducedPerHour() {
        return maxDetailsProducedPerHour;
    }
}
