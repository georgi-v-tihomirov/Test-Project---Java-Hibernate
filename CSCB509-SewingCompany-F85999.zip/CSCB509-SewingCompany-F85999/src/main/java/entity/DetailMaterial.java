package entity;

public enum DetailMaterial {
    LEATHER(3.50), PLASTIC(1.25), SUEDE(5.00), METAL(2.00);

    private double materialPrice;

    DetailMaterial(double price) {this.materialPrice = price; }

    public double getMaterialPrice() { return materialPrice; }

}
