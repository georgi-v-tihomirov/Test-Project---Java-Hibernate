package entity;

import javax.persistence.*;

@Entity
@Table(name = "detail")
public class Detail {
    @Id
    @Column(name = "detail_id", updatable = false, nullable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long detailId;

    @Column(name = "detail_name")
    private String detailName;

    @Column(name = "time_for_creation")
    private double timeForCreation;

    @Column(name = "detail_price")
    private double detailPrice; //Price for making

    @Column(name = "detail_retail_price")
    private double detailSalePrice; //Market price

    @Column(name = "detail_quantity")
    private int detailQuantity;

    @Enumerated(EnumType.STRING)
    @Column(name = "designed_for")
    private DetailDesignedFor detailDesignedFor;

    @Enumerated(EnumType.STRING)
    @Column(name = "detail_material")
    private DetailMaterial detailMaterial;

    @ManyToOne
    @JoinColumn(name="created_by_employee_id", nullable=false)
    private Employee detailCreatedByEmployee;

    public Detail() {}

    public Detail(String name){
        this.detailName = name;
    }

    public Detail(String detailName, DetailDesignedFor detailDesignedFor, DetailMaterial detailMaterial) {
        setDetailName(detailName);
        setDetailDesignedFor(detailDesignedFor);
        setTimeForCreation();
        setDetailQuantity(1);
        setDetailMaterial(detailMaterial);
        setDetailNetPrice();
        setDetailRetailPrice(this.detailPrice);
    }

    public Detail(String detailName,
                  DetailDesignedFor detailDesignedFor,
                  int detailQuantity,
                  DetailMaterial detailMaterial) {
        setDetailName(detailName);
        setDetailDesignedFor(detailDesignedFor);
        setTimeForCreation();
        setDetailQuantity(detailQuantity);
        setDetailMaterial(detailMaterial);
        setDetailNetPrice();
        setDetailRetailPrice(this.detailPrice);
    }

    public Detail(String detailName,
                  DetailDesignedFor detailDesignedFor,
                  int detailQuantity,
                  DetailMaterial detailMaterial,
                  double detailSalePrice) {
        setDetailName(detailName);
        setDetailDesignedFor(detailDesignedFor);
        setTimeForCreation();
        setDetailQuantity(detailQuantity);
        setDetailMaterial(detailMaterial);
        setDetailNetPrice();
        setDetailRetailPrice(detailSalePrice);
    }

    public Detail(long detailId, String detailName,
                  DetailDesignedFor detailDesignedFor,
                  int detailQuantity,
                  DetailMaterial detailMaterial,
                  double detailSalePrice) {
        setDetailId(detailId);
        setDetailName(detailName);
        setTimeForCreation();
        setDetailDesignedFor(detailDesignedFor);
        setDetailQuantity(detailQuantity);
        setDetailMaterial(detailMaterial);
        setDetailNetPrice();
        setDetailRetailPrice(detailSalePrice);
    }

    /*
    public Detail(long detailId, String detailName,
                  double timeForCreation,
                  double detailPrice, DetailDesignedFor detailDesignedFor,
                  DetailMaterial detailMaterial) {
        this.detailId = detailId;
        this.detailName = detailName;
        this.timeForCreation = timeForCreation;
        this.detailPrice = detailPrice;
        this.detailDesignedFor = detailDesignedFor;
        this.detailMaterial = detailMaterial;
    }
*/
    //Function to set the detail price, based on the time for making and price of the material
    public void setDetailNetPrice() {
        double price = (detailMaterial.getMaterialPrice() + detailDesignedFor.getTimeForMaking()) * detailQuantity; //Time + price * quantity
        this.detailPrice = Math.round(price * 100.0) / 100.0;
    }

    //Function to set the market price of the detail
    public void setDetailRetailPrice(double price) {
        //Can't be sold on a price that is lower that the price for creation
        if(detailPrice <= price) {
            this.detailSalePrice = price;
        }
        else {
            this.detailSalePrice = detailPrice;
        }
    }

    public void setTimeForCreation() {
        this.timeForCreation = detailDesignedFor.getTimeForMaking();
    }

    public long getDetailId() {
        return detailId;
    }

    public void setDetailId(long detailId) {
        this.detailId = detailId;
    }

    public String getDetailName() {
        return detailName;
    }

    public void setDetailName(String detailName) {
        this.detailName = detailName;
    }

    public int getDetailQuantity() {
        return detailQuantity;
    }

    public void setDetailQuantity(int detailQuantity) {
        this.detailQuantity = detailQuantity;
    }

    public DetailDesignedFor getDetailDesignedFor() {
        return detailDesignedFor;
    }

    public void setDetailDesignedFor(DetailDesignedFor detailDesignedFor) {
        this.detailDesignedFor = detailDesignedFor;
    }

    public DetailMaterial getDetailMaterial() {
        return detailMaterial;
    }

    public void setDetailMaterial(DetailMaterial detailMaterial) {
        this.detailMaterial = detailMaterial;
    }

    public Employee getDetailCreatedByEmployee() {
        return detailCreatedByEmployee;
    }


    public void setDetailCreatedByEmployee(Employee employee) {
        this.detailCreatedByEmployee = employee;
    }

    public double getTimeForCreation() {
        return timeForCreation;
    }

    public double getDetailPrice() {
        return detailPrice;
    }

    public double getDetailSalePrice() {
        return detailSalePrice;
    }

    /*

    public Detail(String name, DetailDesignedFor designedFor, DetailMaterial material){
        this.detailName = name;
        this.detailDesignedFor = designedFor;
        this.detailMaterial = material;
    }

    public Detail(long id, String name, DetailDesignedFor designedFor, DetailMaterial material){
        this.detailId = id;
        this.detailName = name;
        this.detailDesignedFor = designedFor;
        this.detailMaterial = material;
    }

    public long getDetailId() {
        return detailId;
    }

    public void setDetailId(long detailId) {
        this.detailId = detailId;
    }

    public String getDetailName() {
        return detailName;
    }

    public void setDetailName(String detailName) {
        this.detailName = detailName;
    }

    public DetailDesignedFor getDetailDesignedFor() {
        return detailDesignedFor;
    }

    public void setDetailDesignedFor(DetailDesignedFor detailDesignedFor) {
        this.detailDesignedFor = detailDesignedFor;
    }

    public DetailMaterial getDetailMaterial() {
        return detailMaterial;
    }

    public void setDetailMaterial(DetailMaterial detailMaterial) {
        this.detailMaterial = detailMaterial;
    }

    public Employee getDetailCreatedByEmployee() {
        return detailCreatedByEmployee;
    }

     */

    @Override
    public String toString() {
        return "entity.Detail{" +
                "detailId=" + detailId +
                ", detailName='" + detailName + '\'' +
                ", timeForCreation=" + timeForCreation +
                ", detailPrice=" + detailPrice +
                ", detailSalePrice=" + detailSalePrice +
                ", detailQuantity=" + detailQuantity +
                ", detailDesignedFor=" + detailDesignedFor +
                ", detailMaterial=" + detailMaterial +
                '}';
    }
}
