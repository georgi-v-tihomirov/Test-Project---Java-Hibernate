package entity;

import javax.persistence.*;
import java.time.LocalDate;
import java.util.HashSet;
import java.util.Set;

@Entity
@Table(name = "employee")
public class Employee {
    @Id
    @Column(name = "employee_id", updatable = false, nullable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long employeeId;

    @Column(name = "employee_name", nullable = false)
    private String employeeName;

    @Column(name = "birth_date")
    private LocalDate employeeBirthDate;

    @Enumerated(EnumType.STRING)
    @Column(name = "employee_type")
    private EmployeeType employeeType;

    //These details can be collected from the EmployeeType, but it would be nice to have them here - exceptions
    @Column(name = "wage_per_hour")
    private double wagePerHour;

    @Column(name = "working_hours_day")
    private double workingHoursDaily;

    @ManyToOne
    @JoinColumn(name = "employee_company_id")
    private Company workingInCompany;

    @OneToMany(mappedBy="detailCreatedByEmployee", fetch = FetchType.EAGER)
    private Set<Detail> employeeCreatedDetail;


    private int currentCountCreatedItems; //Couldn't invent a way to tract the time

    public Employee() {
        employeeCreatedDetail = new HashSet();
    }

    public Employee(String name, EmployeeType employeeType) {
        setEmployeeName(name);
        setEmployeeType(employeeType);
        setWagePerHour();
        setWorkingHoursDaily();
        employeeCreatedDetail = new HashSet();

        currentCountCreatedItems = 0;
    }

    //Function for creating detail
    public void createDetail(Detail detail){
        //If it can fit in the time frame and if the employee can make details in the hour - ????? cant count how many hours he worked
        if(detail.getTimeForCreation() < this.getWorkingHoursDaily() &&
                currentCountCreatedItems < employeeType.getMaxDetailsProducedPerHour()) {
            employeeCreatedDetail.add(detail);
            currentCountCreatedItems++;
        }
        detail.setDetailCreatedByEmployee(this);
    }

    public Employee(String name, EmployeeType employeeType, LocalDate birthDate) {
        setEmployeeName(name);
        setEmployeeType(employeeType);
        setEmployeeBirthDate(birthDate);
        setWagePerHour();
        setWorkingHoursDaily();
        employeeCreatedDetail = new HashSet();

        currentCountCreatedItems = 0;
    }

    public Employee(long id, String name, EmployeeType employeeType, LocalDate birthDate) {
        setEmployeeId(id);
        setEmployeeName(name);
        setEmployeeType(employeeType);
        setEmployeeBirthDate(birthDate);
        setWagePerHour();
        setWorkingHoursDaily();
        employeeCreatedDetail = new HashSet();

        currentCountCreatedItems = 0;
    }

    public long getEmployeeId() {
        return employeeId;
    }

    public void setEmployeeId(long employeeId) {
        this.employeeId = employeeId;
    }

    public String getEmployeeName() {
        return employeeName;
    }

    public void setEmployeeName(String employeeName) {
        this.employeeName = employeeName;
    }

    public LocalDate getEmployeeBirthDate() {
        return employeeBirthDate;
    }

    public void setEmployeeBirthDate(LocalDate employeeBirthDate) {
        this.employeeBirthDate = employeeBirthDate;
    }

    public EmployeeType getEmployeeType() {
        return employeeType;
    }

    public void setEmployeeType(EmployeeType employeeType) {
        this.employeeType = employeeType;
    }

    public Company getWorkingInCompany() {
        return workingInCompany;
    }

    public void setWorkingInCompany(Company workingInCompany) {
        this.workingInCompany = workingInCompany;
    }

    public void addToCreatedDetails(Detail detail) { this.employeeCreatedDetail.add(detail); }

    public double getWagePerHour() {
        return wagePerHour;
    }

    public void setWagePerHour() {
        this.wagePerHour = employeeType.getWage();
    }

    public double getWorkingHoursDaily() {
        return workingHoursDaily;
    }

    public void setWorkingHoursDaily() {
        this.workingHoursDaily = employeeType.getWorkingHours();
    }

    @Override
    public String toString() {
        return "entity.Employee{" +
                "employeeId=" + employeeId +
                ", employeeName='" + employeeName + '\'' +
                ", employeeBirthDate=" + employeeBirthDate +
                ", employeeType=" + employeeType +
                ", wagePerHour=" + wagePerHour +
                ", workingHoursDaily=" + workingHoursDaily +
                ", workingInCompany=" + workingInCompany +
                '}';
    }
}
